runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
# *** Spyder Python Console History Log ***
z = [[1,1][2,2]]
z = [[1,1],[2,2]]
z
z[1]
z[0]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sat Oct 26 19:59:06 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Oct 28 15:27:24 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
0.6*0.9
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
inAct = {}
for fs in range(nIn):
    inAct[fs] = 0.6
for initFS1 in range(res):
    print ((initFS1+1.)/res)
    for hid in range(nHid):
        hidden[hid].oldActivity = (initFS1+1.)/res
        hidden[hid].activity = (initFS1+1.)/res
        hidden[hid].onTime = 0
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Nov 20 12:43:07 2013)---
z = rand(2,3)
z
import matplotlib.pyplot as plt
plt.pcolor(z)
plt.show()
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Nov 27 13:39:37 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sat Nov 30 01:00:58 2013)---
stack = []
stack.append(0)
stack.append(1)
stack.append(2)
stack[0]
stack
stack[-1]
stack[-2]
stack
stack.pop(0)
stack
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
exit
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Dec 03 11:34:52 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Dec 04 13:10:56 2013)---
arr = [0,1,2]
arr
arr.pop(0)
arr
arr.append(3)
arr
arr[-1]
arr[-2]
arr[-4]
arr[-3]
arr
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Dec 16 09:31:37 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Dec 17 14:17:06 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [1,1,0]
x
str(x)
''.join(x)
map(str,x)
str(map(str,x))
x
' '.join(map(str,x))
''.join(map(str,x))
int(''.join(map(str,x)),2)
x[2]=1
x
int(''.join(map(str,x)),2)
x = 0
x
x = [0,0,1]
int(''.join(map(str,x)),2)
x = [0,0,0]
int(''.join(map(str,x)),2)
import scipy as np
transitions = np.array(False, ndmin=2, dtype=bool)
transitions
transitions[1][1]=true
transitions[1][1]=True
transitions = np.ndarray(False, shape=(2,2), dtype=bool)
transitions = np.ndarray(shape=(2,2), dtype=bool)
transitions
transitions = np.ndarray(shape=(3,3), dtype=bool)
transitions 
transitions.fill(False)
transitions 
2^3
2^2
2^4
math.pow(2,3)
math.pow(2,4)
np.pow(2,4)
np.power(2,4)
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
int(''.join(map(str,1 for i in range(3))),2)
int(''.join(map(str,(1 for i in range(3)))),2)
int(''.join(map(str,(0 for i in range(3)))),2)
''.join(map(str,(0 for i in range(3)))),2
''.join(map(str,(0 for i in range(3))))
s = ''.join(map(str,(0 for i in range(3))))
s
s[1]
s[1]=0
s[1]='1'
s
int(s)
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [1,2,3]
x
x[-1]
x[-2]
x[-3}
x[-3]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Dec 23 12:47:21 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [0,1,2,3,4,5]
x
x[2:4]
x[2]
[4]
x[4]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sun Jan 05 17:03:30 2014)---
9%3
9%3 is 0
9%3==0
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Jan 07 19:04:19 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess\eldp.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess')
d = ['5','6']
str(d)
int(d[1])
map(int,d)
d.append(['7','8'])
d
map(int,d)
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess\eldp.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess')
d.pop(-1)
d
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess\eldp.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\EvoLearnDataProcess')

##---(Tue Jan 28 01:57:54 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
d = [(1,1),(2,5),(3,2)]
d
max(d)
max(d)[1]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
z = [(0,2),(1,1),(2,0)]
z
z[0]
z[1]
z[2][1]
z[2][0]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
z = [(0,1),(1,2)]
z
max(z)
max(z)[1]
z = [(1,1),(0,2)]
z
max(z)
max(z)[1]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Mar 11 12:51:21 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Thu Mar 13 14:20:33 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Mar 17 12:59:39 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Thu Mar 20 15:53:03 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014\map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014')
import numpy as np
np.random.rand(10)
runfile(r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014\map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014')
np.random.rand()
runfile(r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014\map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014')
2-1<=0
2-3<=0
3*(2-3<=0)
3*(2-1<=0)
runfile(r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014\map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\people\2009\Komarov\2014')

##---(Mon Mar 24 15:38:10 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Mar 24 16:32:45 2014)---
x = {0:0}
x
x[0]
x[0] = `
x[0] = 1
x
x[1] = 2
x
x[z]=y
x[z]='y'
x['z']='y'
x
x[z]
x['z']
x
x = {}
x
x = {0:1;1:-1}
x = {0:1,1:-1}
x
x = {2:1,3:-1}
x
x[0]=1
x[1]=-1
x
z = {x for x>0}
z = {k: v for k, v in x.iteritems() if x[k]<0}
z
z = {k: v for k, v in x.iteritems() if x[k]>0}
z
x
z
x+z
z [0] = -1
z
z[10] = 0
z
x.update(z)
x
z
x[10]
x[10]= 10
x
z
x.update(z)
x
z
z[10] = 10
z
x.update({k:v for k,v in z.iteritems if v>0})
x.update({k:v for k,v in z.iteritems if z[k]>0})
y = {k:v for k,v in z.iteritems if z[k]>0}
x.update({k:v for k,v in z.iteritems() if z[k]>0})
x
z
z[0] = 5
x.update({k:v for k,v in z.iteritems() if v>0})
x
z[50]=50
z
z = {}
z
z[50]=50
z
x.update({k:v for k,v in z.iteritems() if v>0})
x
y
y = [[k,v] for k,v in x.iteritems()]
y
y[:,1]
import np as numpy
import numpy as np
np.ndarray(y)[:,1]
np.ndarray(y)[:,1].sum()
np.array(y)[:,1].sum()
np.array(y)[:,1]
np.array(y)[:,0]
sum(x.itervalues())
sum(v for v in x.itervalues())
sum(v in x.itervalues())
x

##---(Mon Mar 24 22:40:39 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x
x= dict(1=2,3=4)
x
x = {}
x[0]=1
x[1]=2
x
x[2]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x
sum(w for w in x.itervalues())
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Apr 14 18:34:15 2014)---
pip

##---(Mon Apr 14 18:54:48 2014)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Jun 10 13:51:56 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_dyn.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
pw = [[0, 2, 1.], [1, 2, 0.]]
pw
pw[:,]
pw[:][]
pw[0:]
pw[1:]
pw[2:]
pw[:1]
k = 5/100
k
pw[1:][0]
pw[1:,0]
pw[[1:]]
pw[:,[1:]]
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/sigmoid_map.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
x =[[1,1,1],[2,2,2],[3,3,3]]
x
x= zip(*x)
x
x[0:]
x[1:]
x[:1]
x =[[1,1,1],[2,2,2],[3,3,3]]
z = numpy.asarray(zip(*x))
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/sigmoid_map.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Sat Jun 14 20:48:43 2014)---
import cProfile as profile
profile.run(1/(1+np.exp(-10*(0.5-1))))
?
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/sigmoid_map.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Sun Jun 15 19:46:44 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Sun Jun 15 22:50:44 2014)---
x =[]
x.append(1)
x.append(2)
x[-2]
x[-1]

##---(Thu Jun 19 15:57:28 2014)---
x = [1;2]
x = [1,2]
x
x[0]
x[-1]
x[-2]
x.pop(0)
x.append(3)
x
x[-1]
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Sat Jun 21 13:47:55 2014)---
import numpy as np
np.array_equal([1,1,1],[1.,1.,1.])
np.array_equal([1,1,1],[1,1,1])
np.array_equal([1,1,1],[1.0,1.0,1.000])
int(np.array_equal([1,1,1],[1.0,1.0,1.000]))
int(np.array_equal([1,1,1],[1.0,1.0,1.001]))
int(True)
int(False)
int(!False)
int(not False)
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
pw = {0: 1., 1: 0.}
pw.values()
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Mon Aug 11 16:55:07 2014)---
d= []
d+=1
d= [1,2,3]
d
len(d)
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/FSNpy.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Mon Aug 11 19:06:27 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_dyn.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Wed Sep 17 15:30:43 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Wed Sep 17 15:42:57 2014)---
exit
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Wed Sep 17 16:33:22 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/AtomFS_dyn.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')

##---(Tue Nov 18 15:00:27 2014)---
x =1
x

##---(Fri Dec 05 19:32:56 2014)---
runfile('C:/Users/Brutsev/Desktop/Science/!prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Brutsev/Desktop/Science/!prog/FSN')