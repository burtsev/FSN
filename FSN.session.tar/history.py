runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
# *** Spyder Python Console History Log ***
z = [[1,1][2,2]]
z = [[1,1],[2,2]]
z
z[1]
z[0]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sat Oct 26 19:59:06 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Oct 28 15:27:24 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
0.6*0.9
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
inAct = {}
for fs in range(nIn):
    inAct[fs] = 0.6
for initFS1 in range(res):
    print ((initFS1+1.)/res)
    for hid in range(nHid):
        hidden[hid].oldActivity = (initFS1+1.)/res
        hidden[hid].activity = (initFS1+1.)/res
        hidden[hid].onTime = 0
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\NetFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Nov 20 12:43:07 2013)---
z = rand(2,3)
z
import matplotlib.pyplot as plt
plt.pcolor(z)
plt.show()
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Nov 27 13:39:37 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sat Nov 30 01:00:58 2013)---
stack = []
stack.append(0)
stack.append(1)
stack.append(2)
stack[0]
stack
stack[-1]
stack[-2]
stack
stack.pop(0)
stack
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
exit
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Dec 03 11:34:52 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Wed Dec 04 13:10:56 2013)---
arr = [0,1,2]
arr
arr.pop(0)
arr
arr.append(3)
arr
arr[-1]
arr[-2]
arr[-4]
arr[-3]
arr
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Dec 16 09:31:37 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\sigmoid_map.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Tue Dec 17 14:17:06 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [1,1,0]
x
str(x)
''.join(x)
map(str,x)
str(map(str,x))
x
' '.join(map(str,x))
''.join(map(str,x))
int(''.join(map(str,x)),2)
x[2]=1
x
int(''.join(map(str,x)),2)
x = 0
x
x = [0,0,1]
int(''.join(map(str,x)),2)
x = [0,0,0]
int(''.join(map(str,x)),2)
import scipy as np
transitions = np.array(False, ndmin=2, dtype=bool)
transitions
transitions[1][1]=true
transitions[1][1]=True
transitions = np.ndarray(False, shape=(2,2), dtype=bool)
transitions = np.ndarray(shape=(2,2), dtype=bool)
transitions
transitions = np.ndarray(shape=(3,3), dtype=bool)
transitions 
transitions.fill(False)
transitions 
2^3
2^2
2^4
math.pow(2,3)
math.pow(2,4)
np.pow(2,4)
np.power(2,4)
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
int(''.join(map(str,1 for i in range(3))),2)
int(''.join(map(str,(1 for i in range(3)))),2)
int(''.join(map(str,(0 for i in range(3)))),2)
''.join(map(str,(0 for i in range(3)))),2
''.join(map(str,(0 for i in range(3))))
s = ''.join(map(str,(0 for i in range(3))))
s
s[1]
s[1]=0
s[1]='1'
s
int(s)
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [1,2,3]
x
x[-1]
x[-2]
x[-3}
x[-3]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Mon Dec 23 12:47:21 2013)---
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
x = [0,1,2,3,4,5]
x
x[2:4]
x[2]
[4]
x[4]
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\AtomFS_dyn.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')

##---(Sun Jan 05 17:03:30 2014)---
9%3
9%3 is 0
9%3==0
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\FSNpy.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')
runfile(r'C:\Users\Brutsev\Desktop\Science\!prog\FSN\HyperCube_SingleGoal_test.py', wdir=r'C:\Users\Brutsev\Desktop\Science\!prog\FSN')