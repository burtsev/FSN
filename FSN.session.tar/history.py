# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Tue Oct 01 12:31:07 2013)---
runfile(r'C:\Users\Burtsev\Desktop\prog\v-rep\e-puck_memristor.py', wdir=r'C:\Users\Burtsev\Desktop\prog\v-rep')

##---(Thu Sep 18 12:38:37 2014)---
step
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')

##---(Mon Sep 22 17:00:05 2014)---
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')

##---(Tue Oct 21 13:12:34 2014)---
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')

##---(Thu Nov 27 16:57:21 2014)---
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/FSNpy.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
runfile('C:/Users/Burtsev/Desktop/prog/FSN/HyperCube_SingleGoal_test.py', wdir=r'C:/Users/Burtsev/Desktop/prog/FSN')
FSNet.net[1]
FSNet.net[13].problemWeights